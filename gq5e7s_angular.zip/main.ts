﻿import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { MovieWorldAppModule } from './app/movie-world-app.module';

platformBrowserDynamic().bootstrapModule(MovieWorldAppModule);