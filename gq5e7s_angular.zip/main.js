"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
var movie_world_app_module_1 = require("./app/movie-world-app.module");
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(movie_world_app_module_1.MovieWorldAppModule);
//# sourceMappingURL=main.js.map