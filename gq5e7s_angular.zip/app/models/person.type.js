"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Person = (function () {
    function Person() {
    }
    return Person;
}());
exports.Person = Person;
//# sourceMappingURL=person.type.js.map