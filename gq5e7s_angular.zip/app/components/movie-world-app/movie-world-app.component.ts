import { Component } from '@angular/core';

@Component({
    selector: 'movie-world-app',
    templateUrl: './movie-world-app.component.html'
})
export class MovieWorldAppComponent {
    title = "MovieWorld";
}