import { Cast } from "./cast.type";

export interface People {
    cast: Cast[];
}